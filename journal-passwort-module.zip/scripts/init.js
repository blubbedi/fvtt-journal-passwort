
Hooks.once("ready", async () => {
  if (!game.modules.get("socketlib")?.active) {
    console.error("Socketlib ist nicht aktiv.");
    return;
  }

  const socket = globalThis.socketlib.registerModule("journal-passwort");

  socket.register("grantJournalAccess", async ({ playerId, journalName }) => {
    const journal = game.journal.getName(journalName);
    if (!journal) {
      console.warn(`Journal "${journalName}" nicht gefunden`);
      return;
    }

    const permissions = foundry.utils.duplicate(journal.permission);
    permissions[playerId] = CONST.DOCUMENT_PERMISSION_LEVELS.OBSERVER;
    await journal.update({ permission: permissions });

    const user = game.users.get(playerId);
    if (user?.isActive) {
      ui.notifications.info(`Zugriff auf "${journalName}" gewährt.`);
      journal.sheet.render(true);
    }
  });

  console.log("journal-passwort Modul geladen und bereit.");
});
